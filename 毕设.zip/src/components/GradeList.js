import React, { useState, useEffect } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@material-ui/core';
import axios from 'axios';

const GradeList = ({ studentId }) => {
  const [grades, setGrades] = useState([]);

  useEffect(() => {
    fetchGrades();
  }, [studentId]);

  const fetchGrades = async () => {
    const response = await axios.get(`/api/grades/student/${studentId}`);
    setGrades(response.data);
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>课程</TableCell>
            <TableCell>成绩</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {grades.map((grade) => (
            <TableRow key={grade.id}>
              <TableCell>{grade.course.courseName}</TableCell>
              <TableCell>{grade.score}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default GradeList;

