import React, { useState } from 'react';
import { TextField, Button } from '@material-ui/core';
import axios from 'axios';

const StudentForm = ({ onStudentAdded }) => {
  const [student, setStudent] = useState({ studentId: '', name: '' });

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('/api/students', student);
    onStudentAdded();
    setStudent({ studentId: '', name: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        name="studentId"
        label="学号"
        value={student.studentId}
        onChange={handleChange}
        required
      />
      <TextField
        name="name"
        label="姓名"
        value={student.name}
        onChange={handleChange}
        required
      />
      <Button type="submit" variant="contained" color="primary">
        添加学生
      </Button>
    </form>
  );
};

export default StudentForm;

