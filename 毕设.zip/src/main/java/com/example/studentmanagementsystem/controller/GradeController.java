package com.example.studentmanagementsystem.controller;

import com.example.studentmanagementsystem.model.Grade;
import com.example.studentmanagementsystem.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grades")
public class GradeController {
    @Autowired
    private GradeService gradeService;

    @GetMapping("/student/{studentId}")
    public List<Grade> getGradesByStudentId(@PathVariable Long studentId) {
        return gradeService.getGradesByStudentId(studentId);
    }

    @PostMapping
    public Grade createGrade(@RequestBody Grade grade) {
        return gradeService.saveGrade(grade);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Grade> updateGrade(@PathVariable Long id, @RequestBody Grade gradeDetails) {
        Grade grade = gradeService.getGradeById(id);
        if (grade == null) {
            return ResponseEntity.notFound().build();
        }
        grade.setScore(gradeDetails.getScore());
        Grade updatedGrade = gradeService.saveGrade(grade);
        return ResponseEntity.ok(updatedGrade);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGrade(@PathVariable Long id) {
        Grade grade = gradeService.getGradeById(id);
        if (grade == null) {
            return ResponseEntity.notFound().build();
        }
        gradeService.deleteGrade(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/average/{courseId}")
    public ResponseEntity<Double> getAverageScoreByCourse(@PathVariable Long courseId) {
        Double averageScore = gradeService.getAverageScoreByCourse(courseId);
        return ResponseEntity.ok(averageScore);
    }
}

