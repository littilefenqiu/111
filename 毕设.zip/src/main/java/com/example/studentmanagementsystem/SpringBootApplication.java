package com.example.studentmanagementsystem;

public @interface SpringBootApplication {
}
