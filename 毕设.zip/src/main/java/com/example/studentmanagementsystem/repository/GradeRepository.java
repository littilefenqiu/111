package com.example.studentmanagementsystem.repository;

import com.example.studentmanagementsystem.model.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface GradeRepository extends JpaRepository<Grade, Long> {
    List<Grade> findByStudentId(Long studentId);

    @Query("SELECT g FROM Grade g WHERE g.student.id = :studentId AND g.course.id = :courseId")
    Grade findByStudentIdAndCourseId(Long studentId, Long courseId);

    @Query("SELECT AVG(g.score) FROM Grade g WHERE g.course.id = :courseId")
    Double getAverageScoreByCourse(Long courseId);
}

