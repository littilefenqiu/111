INSERT INTO students (student_id, name) VALUES 
('2023001', '张三'),
('2023002', '李四'),
('2023003', '王五');

INSERT INTO courses (course_name) VALUES 
('数学'),
('语文'),
('英语');

INSERT INTO grades (student_id, course_id, score) VALUES 
(1, 1, 85),
(1, 2, 90),
(1, 3, 78),
(2, 1, 92),
(2, 2, 88),
(2, 3, 95),
(3, 1, 76),
(3, 2, 85),
(3, 3, 82);

