import React from 'react';
import { Container, Typography } from '@material-ui/core';
import StudentList from './components/StudentList';
import StudentForm from './components/StudentForm';

function App() {
  return (
    <Container>
      <Typography variant="h2" gutterBottom>
        学生成绩管理系统
      </Typography>
      <StudentForm onStudentAdded={() => {/* 刷新学生列表 */}} />
      <StudentList />
    </Container>
  );
}

export default App;

